"use strict";(self.webpackChunktradingview=self.webpackChunktradingview||[]).push([[2377],{13367:(e,a,r)=>{r.r(a),r.d(a,{HammerJS:()=>n.a});var i=r(11553),n=r.n(i)}}]);
